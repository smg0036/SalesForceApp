package BasicJava.Assignment3;
public class Patterns {
    public static void main(String[] args) {
        int i=1;
        int n=4;
        int num=1;
        while(i<=n){
            System.out.print(num+" ");
            num=num+2;
            i++;
        }
         System.out.println();
        i=1;
        num=2;
        while(i<=n){
            System.out.print(num+" ");
            num=num+2;
            i++;
        }
        System.out.println();
        i=1;
        num=6;
        while(i<=n){
            System.out.print(num+" ");
            num=num+3;
            i++;
        }
        System.out.println();
        i=1;
        num=1;
        n=5;
        while(i<=n){
            System.out.print(num+" ");
            num=num+3;
            i++;
        }
        System.out.println();
        i=1;
        num=0;
        n=5;
        while(i<=n){
            System.out.print(num+" ");
            num=num+4;
            i++;
        }


    }

}
