package BasicJava.Assgnmt1;

public class MathFormulas18 {
    public static void main(String[] args) {

        //to print the result of the following operations.a.-5+8*6b. (55+9) % 9c. 20 + -3*5/8d.5+15/3*2-8%3

        System.out.println(-5+8*6);
        System.out.println((55+9)%9);
        System.out.println(20+-3*5/8);
        System.out.println(5+15/3*2-8%3);
    }
}
