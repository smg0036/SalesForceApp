package BasicJava.Assignment10;
//INCOMPLETE
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

public class FreqCharInString {

    public static void main(String[] args) {



        Scanner sc = new Scanner(System.in);
        System.out.println("Please enter a string: ");
        String input = sc.next();
        HashMap hm = new HashMap();
        Iterator it = hm.entrySet().iterator();



    }
}
