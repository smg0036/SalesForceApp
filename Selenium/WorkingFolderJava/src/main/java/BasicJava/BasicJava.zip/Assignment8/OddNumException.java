package BasicJava.Assignment8;

public class OddNumException extends Exception {

    OddNumException(String str){
        super(str);
    }
}