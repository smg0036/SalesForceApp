package BasicJava.Assignment6;

public class EvenElement {
    public static void main(String[] args) {
        int[] arr = {3,8,9,5,12};

        for(int a:arr){
           if(a%2==0)
            System.out.println(a);
        }
    }

}
